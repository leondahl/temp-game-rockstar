Enemy stuffs

~stuff to be fixed~
Need to fix audio
Need to sync with axe script