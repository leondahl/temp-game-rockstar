﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemyscript : MonoBehaviour
{

    public bool isfacingright;
    public float speed;
    public int health = 3;
    public int knockback;
    public bool debug;

    public GameObject bloodParticle;
    public GameObject deathParticle;
    Color lerpedColor = Color.white;
    private int direction;
    private float scaleFix;
    private float scale;
    private int healthFix;
    private float colorFloat;
    private Rigidbody2D rbody2d;
    private SpriteRenderer srenderer;

    void Start()
    {
        rbody2d = GetComponent<Rigidbody2D>();
        srenderer = GetComponent<SpriteRenderer>();
        bloodParticle.SetActive(false);
        deathParticle.SetActive(false);
        scale = transform.localScale.x;
        healthFix = health;
    }

    // Update is called once per frame
    void Update()
    {
        Debug.Log("Enemy:fix audio when hurt and dead ");
        deathParticle.transform.position = transform.position;

        if (isfacingright == true)
        {
            scaleFix = scale * -1;
            direction = 1;
        }
        else
        {
            direction = -1;
            scaleFix = scale;
        }
        transform.position = new Vector3(transform.position.x + direction * speed, transform.position.y);
        transform.localScale = new Vector3(scaleFix, transform.localScale.y);

        if (health == 0)
        {
            deathParticle.SetActive(true);
            Destroy(gameObject);
        }

        srenderer.color = lerpedColor;
        lerpedColor = Color.Lerp(Color.white, Color.red, colorFloat);


        if (health < healthFix)
        {
            bloodParticle.SetActive(false);
            bloodParticle.SetActive(true);
            healthFix = health;
            colorFloat += 0.33f;
            Debug.Log(colorFloat);
            //Funkar inte
            //FindObjectOfType<AudioManager>().Play("ljudnamn");
        }

        if (debug == true)
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                health--;
                Debug.Log("health is at " + health);

            }
        }

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        isfacingright = !isfacingright;
    }

    //private void OnCollisionEnter2D(Collision2D collision)
    //{
    //    isfacingright = !isfacingright;
    //}

}
